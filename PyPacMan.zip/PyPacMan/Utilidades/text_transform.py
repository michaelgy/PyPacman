x = """(CannonBall,(157,457),157,607,False,2),
(CannonBall,(607,457),157,607,False,2),
(CannonBall,(157,507),157,607,False,2),
(CannonBall,(607,557),157,607,False,2),
(CannonBall,(157,307),157,607,False,2),
(CannonBall,(157,257),157,607,False,2),
(CannonBall,(157,207),157,607,False,2),
(CannonBall,(157,157),157,607,False,2),
(CannonBall,(607,257),157,607,False,2),
(CannonBall,(607,207),157,607,False,2),
(CannonBall,(607,157),157,607,False,2),
(CannonBall,(407,57),57,707,True,2),
(CannonBall,(357,57),57,707,True,2),
(CannonBall,(257,807),807,1207,True,2),
(CannonBall,(457,807),807,1207,True,2),
(CannonBall,(607,307),157,607,False,2),
(CannonBall,(257,807),257,507,False,2),
(CannonBall,(207,907),207,607,False,2),
(CannonBall,(557,857),207,557,False,2),
(CannonBall,(557,957),57,557,False,2),
(CannonBall,(157,1057),157,457,False,2),
(CannonBall,(257,1107),157,257,False,2),
(CannonBall,(357,1157),357,457,False,2),
(CannonBall,(157,57),57,307,True,2),
(CannonBall,(607,57),57,307,True,2),
(CannonBall,(207,307),57,307,True,2),
(CannonBall,(557,307),57,307,True,2),"""

y = """((250,700), hor_mov, ((300,700),2)),
((400,100), ver_mov, ((150,450),2)),
((450,700), ver_mov, ((450,1000),2)),
((200,600), hor_mov, ((400,600),2)),
((1000,300), ver_mov, ((450,1000),2)),
((400,900), ver_mov, ((150,450),2)),
((700,100), ver_mov, ((700,1000),2)),
((1000,900), ver_mov, ((700,1000),2)),
((900,700), hor_mov, ((300,700),2)),
((550,300), vec_mov, (((550, 300), (550, 700), (450,700) ,(450,300)),2))"""

def transform(txt):
    for line in txt.split('\n'):
        line = line[2:]
        p1a = line.find("(")
        p1c = line[p1a:].find(")")
        left, top = line[p1a+1:p1a+p1c].split(",")
        
        line = line[p1a+2+p1c:].split(",")
        minp,maxp = line[0],line[1]
        print("(({},{}), {}, (({},{}),2)),".format(top,left,
        "hor_mov" if line[2] == "False" else "ver_mov",minp,maxp))

transform(x)