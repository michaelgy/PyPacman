#===============================================================================
# En este espacio solo se van a realizar importaciones de librerias o modulos
#===============================================================================
import sys, pygame, os, random
from pygame.locals import *
from Utilidades import *


#===============================================================================
# Constantes
#===============================================================================
# Esta declaracion siempre va aqui ---------------------------------------------
pygame.init()


#pygame.mixer.music.load("Thexxintro.ogg")
#pygame.mixer.music.play(-1)

# Pantalla ---------------------------------------------------------------------
DISPLAY_WIDTH = 1280
DISPLAY_HEIGHT = 720
DISPLAY_FLAGS = 0#FULLSCREEN
DISPLAY_DEPTH = 32 #Opcional

# Cuadros por segundo ----------------------------------------------------------
FPS = 60
fpsClock = pygame.time.Clock()

# Inicializacion de la pantalla ------------------------------------------------
x = pygame.display.mode_ok((DISPLAY_WIDTH,DISPLAY_HEIGHT),DISPLAY_FLAGS,DISPLAY_DEPTH)
DISPLAY_SURF = pygame.display.set_mode((DISPLAY_WIDTH,DISPLAY_HEIGHT),DISPLAY_FLAGS,DISPLAY_DEPTH)

#Inicializacion de superficie de juego

DISPLAY_GAME = Sup(800,600, 60, 165)
DISPLAY_BAR = Sup(150,720, 0, 1130)
DISPLAY_FONT = Sup(1130,720)
DISPLAY_FONT.surf.blit(loadIm("Principal/Menu.png"),(0,0))


# Titulo del juego --------------------------------------------------------
pygame.display.set_caption("Aleph")
# Icono ------------------------------------------------------------------------
pygame.display.set_icon(loadIm('WhiteBoss.png'))

# Pacman -----------------------------------------------------------------------
pac=Pacman("AvatarP1.png","AvatarP2.png")
pac.position(50,50)


# animacion --------------------------------------------------------------------
g_modulo=0
alpha=255
i=1
introm=0
#Mouse
MouseR=MouseRect()

# Estados --------------------------------------------------------------------
# Estados principales
class GStates:
    #Pantalla de inicio
    intro_screen = 0
    #Menu principal
    menu = 1
    #Select Menu
    level_select = 2
    #Juego
    game = 3

# Estados menu
class GStates_menu:
    #Menu en principal
    principal = 0
    #Menu en play
    mplay = 1
    #Menu en info
    minfo = 2
    #Menu en score
    mscore = 3
    #Menu en options
    moptions = 4
    #Menu en creditos
    mcreditos = 5

# Estados seleccionar nivel
class GStates_levelselect:
    normal = 0
    clasico = 1
    survival = 2

# Estados juego
class GStates_level:
    intro = 0
    nivel = 1
    perdiste = 2
    
game_state = GStates.intro_screen
menu_state = GStates_menu.principal
levelselect_state = GStates_levelselect.normal
level_state = GStates_level.intro
#nivel actual
Lvl=0

#===============================================================================
#Niveles config
import Nivel1
import Nivel2

#Configuracion de la pantalla
import Principal


#===============================================================================
# Bucle principal

# Etiqueta para indicar que es la primera vez que se ingresa a un estado
tag_first_in = True

while True:
    #Atrapar todos los eventos del juego en la escena actual
    events = pygame.event.get()

    if game_state == GStates.intro_screen:
        introm = (introm+1)%125
        xIntro=Principal.xxIntro(introm)
        DISPLAY_SURF.blit(xIntro.surf,xIntro.rect)

        for event in events:
            if event.type == KEYDOWN:
                if event.key == K_RETURN:
                    game_state = GStates.menu

    elif game_state == GStates.menu:
        xMenu=Principal.xxMenu()
        MouseR.update()

        if menu_state == GStates_menu.principal:
            pass

        elif menu_state == GStates_menu.mplay:
            Principal.BotNormal.update(xMenu.surf,MouseR)
            Principal.BotClassic.update(xMenu.surf,MouseR)
            Principal.BotSurvival.update(xMenu.surf,MouseR)

            for event in events:
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if MouseR.colliderect(Principal.BotNormal.imgpos):
                        menu_state = GStates_menu.principal
                        game_state = GStates.level_select
                        levelselect_state = GStates_levelselect.normal
                    
                    elif MouseR.colliderect(Principal.BotClassic.imgpos):
                        menu_state = GStates_menu.principal
                        game_state = GStates.level_select
                        levelselect_state = GStates_levelselect.clasico
                    
                    elif MouseR.colliderect(Principal.BotSurvival.imgpos):
                        menu_state = GStates_menu.principal
                        game_state = GStates.level_select
                        levelselect_state = GStates_levelselect.survival
                           
        elif menu_state == GStates_menu.minfo:
            pass

        elif menu_state == GStates_menu.mscore:
            
            pass

        elif menu_state == GStates_menu.moptions:
            
            pass

        elif menu_state == GStates_menu.mcreditos:
            TextObj(Principal.fontObj1,"Michael G.", YELLOW).update_center(xMenu.surf,((xMenu.rect.width/2)+200,360))

            TextObj(Principal.fontObj1,"Juan Fer. E.", YELLOW).update_center(xMenu.surf,((xMenu.rect.width/2)+200,460))
                
        Principal.BotPlay.update(xMenu.surf,MouseR)
        Principal.BotInfo.update(xMenu.surf,MouseR)
        Principal.BotScores.update(xMenu.surf,MouseR)
        Principal.BotOptions.update(xMenu.surf,MouseR)
        Principal.BotCredits.update(xMenu.surf,MouseR)

        TextObj(Principal.fontObj1,"Aleph", YELLOWS).update_center(xMenu.surf, (xMenu.rect.width/2,100))

        DISPLAY_SURF.blit(xMenu.surf,xMenu.rect)

        for event in events:
            if event.type==pygame.MOUSEBUTTONDOWN:
                if MouseR.colliderect(Principal.BotPlay.imgpos):
                    if menu_state == GStates_menu.mplay:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.mplay
                
                elif MouseR.colliderect(Principal.BotInfo.imgpos):
                    if menu_state == GStates_menu.minfo:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.minfo
                
                elif MouseR.colliderect(Principal.BotScores.imgpos):
                    if menu_state == GStates_menu.mscore:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.mscore
                
                elif MouseR.colliderect(Principal.BotOptions.imgpos):
                    if menu_state == GStates_menu.moptions:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.moptions

                elif MouseR.colliderect(Principal.BotCredits.imgpos):
                    if menu_state == GStates_menu.mcreditos:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.mcreditos
        pass

    elif game_state == GStates.level_select:
        MouseR.update()
        fondo = Principal.xxMenu()
        if levelselect_state == GStates_levelselect.normal:
            Principal.MenuL.update(fondo.surf)
            
            TextObj(Principal.fontObj2, "Normal Mode", YELLOWS).update_center(fondo.surf,(fondo.rect.width*3/4-50,100))
            
            Principal.BotBack.update(fondo.surf,MouseR)
            DISPLAY_SURF.blit(fondo.surf,(0,0))

            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    index = MouseR.collidelist(Principal.MenuL.img_rect)
                    if index>-1:
                        game_state = GStates.game
                        Lvl = index+1
                        level_state = GStates_level.intro

        if levelselect_state == GStates_levelselect.clasico:
            Principal.BotBack.update(fondo.surf,MouseR)
            DISPLAY_SURF.blit(fondo.surf,(0,0))
        
        if levelselect_state == GStates_levelselect.survival:
            Principal.BotBack.update(fondo.surf,MouseR)
            DISPLAY_SURF.blit(fondo.surf,(0,0))

        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if MouseR.colliderect(Principal.BotBack.imgpos):
                    game_state = GStates.menu

    elif game_state == GStates.game:
        if level_state == GStates_level.intro or level_state == GStates_level.perdiste:
            if tag_first_in:
                tag_first_in = False

                if level_state == GStates_level.perdiste:
                    Principal.texto_perdiste()
                else:
                    Principal.levelHistTexto(Principal.historia_intro_text[Lvl-1])
                
            MouseR.update()
            xHistoria=Principal.xxHistoria()
            Principal.BotStart.update(xHistoria.surf,MouseR)
            Principal.BotReturn.update(xHistoria.surf,MouseR)
            DISPLAY_SURF.blit(xHistoria.surf,xHistoria.rect)

            Principal.animacionHistTexto(DISPLAY_SURF)

            #indicador para la salida del estado intro/perdiste
            tag_out = False
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if MouseR.colliderect(Principal.BotStart.imgpos):
                        level_state = GStates_level.nivel
                        tag_out = True
                        
                    elif MouseR.colliderect(Principal.BotReturn.imgpos):
                        game_state = GStates.menu
                        tag_out = True
            if tag_out:
                Principal.pergamino_fondo.imagen = loadImA("Principal/Historia.png")
                Principal.pergamino_derecha.rect.left=640
                Principal.pergamino_izquierda.rect.left=510
                tag_first_in = True
        
        if level_state == GStates_level.nivel:
            DISPLAY_GAME.surf.fill(WHITE)

            Nivel1.DISPLAY_LEVEL.surf.blit(Nivel1.DISPLAY_BACKGROUND.surf,(0,0))
            
            if pac.rect.left>=DISPLAY_GAME.rect.width/2 and pac.direccion==1 and pac.limitleft<=(50*len(Nivel1.l_texto[0])-DISPLAY_GAME.rect.width):
                lefm = 2
            elif pac.rect.left<=DISPLAY_GAME.rect.width/2 and pac.direccion==2 and pac.limitleft>=0:
                lefm = -2
            else:
                lefm = 0
            
            if pac.rect.top<=DISPLAY_GAME.rect.height/2 and pac.direccion==3 and pac.limittop>=0:
                topm = 2
            elif pac.rect.top>=DISPLAY_GAME.rect.height/2 and pac.direccion==4 and pac.limittop<=(50*len(Nivel1.l_texto)-DISPLAY_GAME.rect.height):
                topm = -2
            else:
                topm = 0

            if lefm != 0:
                Nivel1.DISPLAY_LEVEL.rect.left -= lefm #DISPLAY_GAME.rect.width/400
                pac.rect.left -= lefm #DISPLAY_GAME.rect.width/400
                pac.rect1.left -= lefm #DISPLAY_GAME.rect.width/400
                pac.limitleft += lefm #DISPLAY_GAME.rect.width/400
                for e in Nivel1.muros.final_wall:
                    e.left -= lefm #DISPLAY_GAME.rect.width/400
                for e in Nivel1.coins.coins:
                    e.rect.left-= lefm
                Nivel1.metarect.left-=lefm
                for e in Nivel1.Bonus:
                    e.rect1.left -= lefm

            if topm != 0:
                Nivel1.DISPLAY_LEVEL.rect.top += topm#DISPLAY_GAME.rect.height/300
                pac.rect.top += topm #DISPLAY_GAME.rect.width/400
                pac.rect1.top += topm #DISPLAY_GAME.rect.width/400
                pac.limittop-= topm #DISPLAY_GAME.rect.width/400
                for e in Nivel1.muros.final_wall:
                    e.top+= topm #DISPLAY_GAME.rect.width/400
                for e in Nivel1.coins.coins:
                    e.rect.top+= topm
                Nivel1.metarect.top+= topm
                for e in Nivel1.Bonus:
                    e.rect1.top += topm
            
            Nivel1.DISPLAY_LEVEL.surf.blit(Nivel1.metacol,Nivel1.metacolrect)
            
            for e in Nivel1.Bonus:
                if e.flag:
                    e.update(Nivel1.DISPLAY_LEVEL)
                    if pac.rect1.colliderect(e.rect1):
                        e.flag=False
                        pac.lifes+=1
                        pac.lifesurf=[[pac.life_surf,pac.life_surf.get_rect()] for e in range (pac.lifes)]
            
            for enem in Nivel1.enemiesObj:
                enem.Mov_enemie(Nivel1.DISPLAY_LEVEL)
                Nivel1.DISPLAY_LEVEL.surf.blit(enem.actual,enem.anirect)

            DISPLAY_GAME.surf.blit(Nivel1.DISPLAY_LEVEL.surf,Nivel1.DISPLAY_LEVEL.rect)
            """for enem in Nivel1.enemiesObj:
                pygame.draw.rect(DISPLAY_GAME.surf, (0,0,255),enem.colrect,1)"""
            
            Nivel1.coins.upgrades(DISPLAY_GAME.surf)
            
            if pac.lifes:
            
                if pac.rect1.collidelistall(Nivel1.ENEMIGOS):
                    
                    for e in Nivel1.ENEMIGOS:
                        e.left+=pac.limitleft
                        e.top+=pac.limittop
                    
                    for e in Nivel1.coins.coins:
                        e.rect.left+=pac.limitleft
                        e.rect.top+=pac.limittop

                    for e in Nivel1.Bonus:
                        e.rect1.left+=pac.limitleft
                        e.rect1.top+=pac.limittop

                    pac.direccion=1
                    pac.lifesurf.pop()
                    pac.lifes-=1
                    pac.lifesurf=[[pac.life_surf,pac.life_surf.get_rect()] for e in range (pac.lifes)]
                    pac.position(50,50)
                    Nivel1.DISPLAY_LEVEL.rect.top=0
                    Nivel1.DISPLAY_LEVEL.rect.left=0
                    for e in Nivel1.muros.final_wall:
                        e.top+=pac.limittop
                        e.left+=pac.limitleft
                    Nivel1.metarect.top+=pac.limittop
                    Nivel1.metarect.left+=pac.limitleft
                    pac.limitleft=0
                    pac.limittop=0
                
                elif Nivel1.coins.amount==0 and pac.rect1.colliderect(Nivel1.metarect):
                    Nivel1.metarect.top+=pac.limittop
                    Nivel1.metarect.left+=pac.limitleft
                    ControladorP=3
                    LvlState=2
                    Nivel1.coins.coins=[]
                    Nivel1.coins.rects=[]
                    Nivel1.coins.amount=174
                    pac.coins_eaten=0
                    pac.lifes=3
                    pac.lifesurf=[[pac.life_surf,pac.life_surf.get_rect()] for e in range (pac.lifes)]
                    pac.position(50,50)
                    Nivel1.DISPLAY_BACKGROUND.rect.top=0
                    Nivel1.DISPLAY_BACKGROUND.rect.left=0

                else:
                    pac.upgrade(DISPLAY_GAME,Nivel1.coins,Nivel1.muros)

                    textSurfaceObj = Principal.fontObj.render(str(pac.coins_eaten), True, YELLOW, BLACK)
                    textRectObj = textSurfaceObj.get_rect()
                    DISPLAY_GAME.surf.blit(textSurfaceObj,textRectObj)
            else:
                for e in Nivel1.Bonus:
                    e.flag = True
                Nivel1.metarect.top+=pac.limittop
                Nivel1.metarect.left+=pac.limitleft
                Nivel1.coins.coins=Nivel1.coins.coinsave
                Nivel1.coins.rects=Nivel1.coins.rectsave
                Nivel1.coins.amount=174
                pac.coins_eaten=0
                pac.lifes=3
                pac.lifesurf=[[pac.life_surf,pac.life_surf.get_rect()] for e in range (pac.lifes)]
                pac.position(50,50)
                Nivel1.DISPLAY_BACKGROUND.rect.top=0
                Nivel1.DISPLAY_BACKGROUND.rect.left=0
                for e in Nivel1.muros.final_wall:
                    e.top+=pac.limittop
                    e.left+=pac.limitleft
                pac.limitleft=0
                pac.limittop=0
                level_state = GStates_level.perdiste

            DISPLAY_BAR.surf.fill(YELLOW)

            TextObj(Principal.fontObj, "Score", BLACK).update_center(DISPLAY_BAR.surf, (DISPLAY_BAR.rect.width/2,50))
            TextObj(Principal.fontObj, str(pac.coins_eaten*50), BLACK).update_center(DISPLAY_BAR.surf, (DISPLAY_BAR.rect.width/2,100))
            
            TextObj(Principal.fontObj, "Lifes", BLACK).update_center(DISPLAY_BAR.surf, (DISPLAY_BAR.rect.width/2,150))
            pac.life_blit(DISPLAY_BAR.surf)

            TextObj(Principal.fontObj, "Time", BLACK).update_center(DISPLAY_BAR.surf, (DISPLAY_BAR.rect.width/2,320))
            TextObj(Principal.fontObj, str(round(pygame.time.get_ticks()/1000.0,1)), BLACK).update_center(DISPLAY_BAR.surf, (DISPLAY_BAR.rect.width/2,350))

            DISPLAY_SURF.fill(BLACK)
            DISPLAY_SURF.blit(DISPLAY_GAME.surf,DISPLAY_GAME.rect)
            DISPLAY_SURF.blit(DISPLAY_BAR.surf,DISPLAY_BAR.rect)

            for event in events:
                if event.type == KEYDOWN:
                    if event.key == K_RIGHT:
                        pac.direccion=1
                    elif event.key == K_LEFT:
                        pac.direccion=2
                    elif event.key == K_UP:
                        pac.direccion=3
                    elif event.key == K_DOWN:
                        pac.direccion=4

    #Salir del juego
    for event in events:
        if event.type == QUIT:
            print("QUIT event has occurred!")
            pygame.quit()
            sys.exit()
        elif event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                print("ESCAPE event has occurred!")
                pygame.quit()
                sys.exit()
    
    pygame.display.update()
    fpsClock.tick(FPS)