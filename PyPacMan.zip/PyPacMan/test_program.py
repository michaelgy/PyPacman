from time import time_ns


def test(f1,f2):
    n = 500
    total1 = 0
    tst = time_ns()
    for _ in range(n):
        ts = time_ns()
        f1()
        tf = time_ns()
        total1 += tf-ts
    total2 = 0
    for _ in range(n):
        ts = time_ns()
        f2()
        tf = time_ns()
        total2 += tf-ts
    tft = time_ns()
    print("promedio f1: {} s".format(total1/n*1/10**9))
    print("promedio f2: {} s".format(total2/n*1/10**9))
    print("tiempo prueba: {} s".format((tft-tst)/10**9))

def test_1():
    for i in range(101):
        if i == 100:
	        print('100')
        if i == 99:
            print('99')
        if i == 98:
            print('98')
        if i == 97:
            print('97')
        if i == 96:
            print('96')
        if i == 95:
            print('95')
        if i == 94:
            print('94')
        if i == 93:
            print('93')
        if i == 92:
            print('92')
        if i == 91:
            print('91')
        if i == 90:
            print('90')
        if i == 89:
            print('89')
        if i == 88:
            print('88')
        if i == 87:
            print('87')
        if i == 86:
            print('86')
        if i == 85:
            print('85')
        if i == 84:
            print('84')
        if i == 83:
            print('83')
        if i == 82:
            print('82')
        if i == 81:
            print('81')
        if i == 80:
            print('80')
        if i == 79:
            print('79')
        if i == 78:
            print('78')
        if i == 77:
            print('77')
        if i == 76:
            print('76')
        if i == 75:
            print('75')
        if i == 74:
            print('74')
        if i == 73:
            print('73')
        if i == 72:
            print('72')
        if i == 71:
            print('71')
        if i == 70:
            print('70')
        if i == 69:
            print('69')
        if i == 68:
            print('68')
        if i == 67:
            print('67')
        if i == 66:
            print('66')
        if i == 65:
            print('65')
        if i == 64:
            print('64')
        if i == 63:
            print('63')
        if i == 62:
            print('62')
        if i == 61:
            print('61')
        if i == 60:
            print('60')
        if i == 59:
            print('59')
        if i == 58:
            print('58')
        if i == 57:
            print('57')
        if i == 56:
            print('56')
        if i == 55:
            print('55')
        if i == 54:
            print('54')
        if i == 53:
            print('53')
        if i == 52:
            print('52')
        if i == 51:
            print('51')
        if i == 50:
            print('50')
        if i == 49:
            print('49')
        if i == 48:
            print('48')
        if i == 47:
            print('47')
        if i == 46:
            print('46')
        if i == 45:
            print('45')
        if i == 44:
            print('44')
        if i == 43:
            print('43')
        if i == 42:
            print('42')
        if i == 41:
            print('41')
        if i == 40:
            print('40')
        if i == 39:
            print('39')
        if i == 38:
            print('38')
        if i == 37:
            print('37')
        if i == 36:
            print('36')
        if i == 35:
            print('35')
        if i == 34:
            print('34')
        if i == 33:
            print('33')
        if i == 32:
            print('32')
        if i == 31:
            print('31')
        if i == 30:
            print('30')
        if i == 29:
            print('29')
        if i == 28:
            print('28')
        if i == 27:
            print('27')
        if i == 26:
            print('26')
        if i == 25:
            print('25')
        if i == 24:
            print('24')
        if i == 23:
            print('23')
        if i == 22:
            print('22')
        if i == 21:
            print('21')
        if i == 20:
            print('20')
        if i == 19:
            print('19')
        if i == 18:
            print('18')
        if i == 17:
            print('17')
        if i == 16:
            print('16')
        if i == 15:
            print('15')
        if i == 14:
            print('14')
        if i == 13:
            print('13')
        if i == 12:
            print('12')
        if i == 11:
            print('11')
        if i == 10:
            print('10')

def test_2():
    for i in range(101):
        if i == 10:
            print(i)
    for i in range(101):
        if i == 11:
            print(i)
    for i in range(101):
        if i == 12:
            print(i)
    for i in range(101):
        if i == 13:
            print(i)
    for i in range(101):
        if i == 14:
            print(i)
    for i in range(101):
        if i == 15:
            print(i)
    for i in range(101):
        if i == 16:
            print(i)
    for i in range(101):
        if i == 17:
            print(i)
    for i in range(101):
        if i == 18:
            print(i)
    for i in range(101):
        if i == 19:
            print(i)
    for i in range(101):
        if i == 20:
            print(i)
    for i in range(101):
        if i == 21:
            print(i)
    for i in range(101):
        if i == 22:
            print(i)
    for i in range(101):
        if i == 23:
            print(i)
    for i in range(101):
        if i == 24:
            print(i)
    for i in range(101):
        if i == 25:
            print(i)
    for i in range(101):
        if i == 26:
            print(i)
    for i in range(101):
        if i == 27:
            print(i)
    for i in range(101):
        if i == 28:
            print(i)
    for i in range(101):
        if i == 29:
            print(i)
    for i in range(101):
        if i == 30:
            print(i)
    for i in range(101):
        if i == 31:
            print(i)
    for i in range(101):
        if i == 32:
            print(i)
    for i in range(101):
        if i == 33:
            print(i)
    for i in range(101):
        if i == 34:
            print(i)
    for i in range(101):
        if i == 35:
            print(i)
    for i in range(101):
        if i == 36:
            print(i)
    for i in range(101):
        if i == 37:
            print(i)
    for i in range(101):
        if i == 38:
            print(i)
    for i in range(101):
        if i == 39:
            print(i)
    for i in range(101):
        if i == 40:
            print(i)
    for i in range(101):
        if i == 41:
            print(i)
    for i in range(101):
        if i == 42:
            print(i)
    for i in range(101):
        if i == 43:
            print(i)
    for i in range(101):
        if i == 44:
            print(i)
    for i in range(101):
        if i == 45:
            print(i)
    for i in range(101):
        if i == 46:
            print(i)
    for i in range(101):
        if i == 47:
            print(i)
    for i in range(101):
        if i == 48:
            print(i)
    for i in range(101):
        if i == 49:
            print(i)
    for i in range(101):
        if i == 50:
            print(i)
    for i in range(101):
        if i == 51:
            print(i)
    for i in range(101):
        if i == 52:
            print(i)
    for i in range(101):
        if i == 53:
            print(i)
    for i in range(101):
        if i == 54:
            print(i)
    for i in range(101):
        if i == 55:
            print(i)
    for i in range(101):
        if i == 56:
            print(i)
    for i in range(101):
        if i == 57:
            print(i)
    for i in range(101):
        if i == 58:
            print(i)
    for i in range(101):
        if i == 59:
            print(i)
    for i in range(101):
        if i == 60:
            print(i)
    for i in range(101):
        if i == 61:
            print(i)
    for i in range(101):
        if i == 62:
            print(i)
    for i in range(101):
        if i == 63:
            print(i)
    for i in range(101):
        if i == 64:
            print(i)
    for i in range(101):
        if i == 65:
            print(i)
    for i in range(101):
        if i == 66:
            print(i)
    for i in range(101):
        if i == 67:
            print(i)
    for i in range(101):
        if i == 68:
            print(i)
    for i in range(101):
        if i == 69:
            print(i)
    for i in range(101):
        if i == 70:
            print(i)
    for i in range(101):
        if i == 71:
            print(i)
    for i in range(101):
        if i == 72:
            print(i)
    for i in range(101):
        if i == 73:
            print(i)
    for i in range(101):
        if i == 74:
            print(i)
    for i in range(101):
        if i == 75:
            print(i)
    for i in range(101):
        if i == 76:
            print(i)
    for i in range(101):
        if i == 77:
            print(i)
    for i in range(101):
        if i == 78:
            print(i)
    for i in range(101):
        if i == 79:
            print(i)
    for i in range(101):
        if i == 80:
            print(i)
    for i in range(101):
        if i == 81:
            print(i)
    for i in range(101):
        if i == 82:
            print(i)
    for i in range(101):
        if i == 83:
            print(i)
    for i in range(101):
        if i == 84:
            print(i)
    for i in range(101):
        if i == 85:
            print(i)
    for i in range(101):
        if i == 86:
            print(i)
    for i in range(101):
        if i == 87:
            print(i)
    for i in range(101):
        if i == 88:
            print(i)
    for i in range(101):
        if i == 89:
            print(i)
    for i in range(101):
        if i == 90:
            print(i)
    for i in range(101):
        if i == 91:
            print(i)
    for i in range(101):
        if i == 92:
            print(i)
    for i in range(101):
        if i == 93:
            print(i)
    for i in range(101):
        if i == 94:
            print(i)
    for i in range(101):
        if i == 95:
            print(i)
    for i in range(101):
        if i == 96:
            print(i)
    for i in range(101):
        if i == 97:
            print(i)
    for i in range(101):
        if i == 98:
            print(i)
    for i in range(101):
        if i == 99:
            print(i)
    for i in range(101):
        if i == 100:
            print(i)

test(test_1, test_2)