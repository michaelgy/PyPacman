#import sys
# insert at 1, 0 is the script path (or '' in REPL)
#sys.path.insert(1, 'Z:\\documentos\\descargas\\PyPacMan\\Utilidades')
from .colors import *
from .Objetos import *
