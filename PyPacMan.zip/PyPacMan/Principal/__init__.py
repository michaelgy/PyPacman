import pygame
from Utilidades import *
from pygame.locals import *

#Fuente
fontObj = pygame.font.Font('Pacman1.TTF', 32)
fontObj1 = pygame.font.Font('Pacman1.TTF', 100)
fontObj2 = pygame.font.Font('Pacman1.TTF', 70)

#Intro
xxintro = loadIm("Principal/Intro.png")

#Fondo del menu
xxmenu = loadImA("Principal/Menu.png")

#Pergamino de historia
pergamino_fondo = Obj("Principal/Historia.png")
pergamino_derecha = Obj("Principal/Historia2.png", 0, 640)
pergamino_izquierda = Obj("Principal/Historia3.png", 0, 510)


MatrizNiveles=[["Principal/Nivel1.png","Principal/Nivel1b.png",(600,200,620,50),"Principal/Nivel1Font.png"],
               ["Principal/Nivel2.png","Principal/Nivel2b.png",(620,270,620,50),"Principal/Nivel2Font.png"],
               ["Principal/Nivel3.png","Principal/Nivel3b.png",(610,340,620,50),"Principal/Nivel3Font.png"],
               ["Principal/Nivel4.png","Principal/Nivel4b.png",(612,410,620,50),"Principal/Nivel4Font.png"],
               ["Principal/Nivel5.png","Principal/Nivel5b.png",(730,480,620,50),"Principal/Nivel5Font.png"]]

MenuL=MenuLevels(MatrizNiveles,1280,720)

BotNormal   =   Botones("Principal/NormalMode1.png",    "Principal/NormalMode2.png", 375,200 )
BotClassic  =   Botones("Principal/ClassicMode1.png",   "Principal/ClassicMode2.png",375,270 )
BotSurvival =   Botones("Principal/SurvivalMode.png",   "Principal/SurvivalMode1.png",375,340 )
BotInfo     =   Botones("Principal/Info.png",           "Principal/Info1.png",       100,410 )
BotScores   =   Botones("Principal/Scores.png",         "Principal/Scores1.png",     100,480 )
BotOptions  =   Botones("Principal/Options1.png",       "Principal/Options2.png",    100,550 )
BotCredits  =   Botones("Principal/Credits.png",        "Principal/Credits1.png",    100,620 )
BotPlay     =   Botones("Principal/Play.png",           "Principal/Play1.png",       100,255 )

BotBack     =   Botones("Principal/Back.png",           "Principal/Back1.png",      100,620)
BotReturn   =   Botones("Principal/Return.png",         "Principal/Return1.png",    530,680)
BotStart    =   Botones("Principal/Start.png",          "Principal/Start1.png",     530,20)

historia_intro_text = [
    """Lvl 1
Cuenta la leyenda que el hechicero
del reino mato al rey y secuestro a
la princesa en su propio castillo,
ademas de apoderarse del pueblo.
Con el fin de que nadie le hiciera
frente, exilio a los mas fuertes del
reino en el bosque, esperando que las
bestias se los comiesen.
Tu aventura comienza aqui. Eres el
ultimo sobreviviente, escapa del
bosque no sin antes recoger el dinero
que dejaron los otros heroes.""",
    """Lvl 2
Lo has hecho muy bien, pero no creas
que derrotar al hechicero es lo mismo
que escapar de un simple bosque. Debes
hacerte mas fuerte para poder por lo
menos acercarte al castillo sin que.
el poder del hechicero te haga pedazos
Has escuchado rumores de un sabio que
puede entrenarte y guiarte y asi poder
conseguir el poder necesario. Pero no
olvides que no hay almuerzo gratis y
debes reunir mas dinero para pagarle.
Ve a la ciudad en su encuentro. Ten
mucho cuidado, el hechicero oyo de ti
y ha mandado soldados para matarte.""",
    """Lvl 3
Tu entrenamiento ha ido muy bien, eres
mas fuerte, pero no lo suficiente como
para acercarte al hechicero todavia.
El sabio te dice que en la montania mas
alta del reino yace una fuente de poder
capaz de multiplicar tus fuerzas para
poder hacerle frente al hechicero.
En tu camino escuchas rumores de que
casualmente el hechicero ha estado
transportando el tesoro del reino en
la montania, seguramente para robarlo.
Recupera el dinero tambien, pero ten
cuidado, seguramente esta custodiado.""",
    """Lvl 4
Has recorrido toda la montania y no
encuentras el poder prometido, de
igual manera notas que falta mucho
dinero.
Tal vez te han enganiado. Espera...
Es un hueco! La montania es un volcan
Internate en el y recupera lo que
falta del tesoro, ahi tambien debe
estar la fuente poder de la que
hablaba el sabio. Debe de estar muy
protegida.""",
    """Lvl 5
Tu aventura esta llegando a su fin.
Has entrado al castillo sin que el
poder del hechicero te afecte.
Esquiva todos los guardianes que
obstaculicen tu camino y elimina
al hechicero.
No olvides recuperar en el camino
la parte del tesoro que todavia
no habia sido transportada al
volcan.
Mucha suerte heroe, eres la gran
esperanza de todo el reino."""
]

def xxIntro(intromod):
    DISPLAY_INTRO = Sup(1280,720)
    DISPLAY_INTRO.surf.blit(xxintro,(0,0))
    if intromod>=50:
        TextObj(fontObj,"Press Enter to Start",GREEN).update_center(DISPLAY_INTRO.surf,(DISPLAY_INTRO.rect.width/2,600))
    return DISPLAY_INTRO

def xxMenu():
    DISPLAY_MENU = Sup(1280,720)
    DISPLAY_MENU.surf.blit(xxmenu,(0,0))
    return DISPLAY_MENU

def xxHistoria():
    DISPLAY_MENU = Sup(1280,720)
    DISPLAY_MENU.surf.fill(BLACK) #DISPLAY_MENU.surf.blit(xxhistoria,(0,0))
    return DISPLAY_MENU

def HistTexto(texto,y):
    """Luego de llamar a este metodo se debe recuperar posteriormente
    el fondo del pergamino
    """
    TextObj(fontObj,texto, BLACK).update_left_top(pergamino_fondo.imagen, 110,y)

def levelHistTexto(texto):
    lines = texto.split('\n')
    HistTexto(lines[0],70)
    texto_top = 120
    for line in lines[1:]:
        HistTexto(line,texto_top)
        texto_top+=30

def texto_perdiste():
    HistTexto("Perdiste, pero lo puedes volver",200)
    HistTexto("a intentar de nuevo",230)

def reset_animHisTexto():
    #pergamino_fondo.imagen = pergamino_fondo.imagen_default.copy()
    pergamino_derecha.rect.left, pergamino_derecha.rect.top = (0, 640)
    pergamino_izquierda.rect.left, pergamino_izquierda.rect.top = (0, 510)

def animacionHistTexto(display_surf):
    """Luego de llamar a este metodo se debe recuperar posteriormente
    las posiciones iniciales de los pergaminos
    """
    perg_izq_rect = pergamino_izquierda.rect
    #pos inicial pergamino izquierda
    init_pos = 510
    subs_rect = Rect(
        pergamino_fondo.rect.centerx - perg_izq_rect.width/2 - ( init_pos - perg_izq_rect.left ),
        0,
        pergamino_derecha.rect.left - perg_izq_rect.left,
        pergamino_fondo.rect.height
    )
    subs_perg = pergamino_fondo.imagen.subsurface(subs_rect)
    subs_rect.top = 80
    subs_rect.left += 130
    display_surf.blit(subs_perg, subs_rect)
    display_surf.blit(pergamino_izquierda.imagen, pergamino_izquierda.rect)
    display_surf.blit(pergamino_derecha.imagen, pergamino_derecha.rect)
    if pergamino_izquierda.rect.left!=70:
        pergamino_izquierda.rect.left-=5
        pergamino_derecha.rect.left+=5

