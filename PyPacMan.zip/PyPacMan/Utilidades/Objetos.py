import pygame
from random import randint
from copy import deepcopy
from math import copysign
# for add a method to a instance object variable
from types import MethodType
# for lightdata types (like enums in C++)
from collections import namedtuple

BLACK = (0,0,0)
YELLOW = (255,224,51)

#===============================================================================
# GENERAL UTILITIES
#===============================================================================
def load_level_design(folder_path):
    """load the nivel_design.txt file inside the folder given by the folder_path
    """
    with open(folder_path+'/nivel_design.txt', 'r') as f:
        lines = [line.strip() for line in f.readlines()]
    return lines

def loadIm(path):
    return pygame.image.load(path).convert()

def loadImA(path):
    return pygame.image.load(path).convert_alpha()

def get_list_image(image_path, load_function = loadImA, width = 1, height = 1):
    if isinstance(image_path,str):
        if image_path != "":
            image = [loadImA(image_path)]
        else:
            image = [pygame.Surface((width,height))]
    elif isinstance(image_path, pygame.Surface):
        image = [image_path]
    else:
        """The following check that image_path is iterable if it is
        then it's asume that is a iterable of pygame.Surface objects
        or it's a iterable of strings
        """
        iter(image_path)
        if isinstance(image_path[0],str):
            image = [load_function(e) for e in image_path]
        else:
            image = image_path
    return image

def sign(x):
    """returns 0 if x == 0 else sign(x)
    """
    x = round(x)
    return copysign(1,x) if abs(x)>0 else 0


class Sup(pygame.Surface):
    def __init__(self,width,height,top=0,left=0):
        self.surf=pygame.Surface((width,height))
        self.rect=self.surf.get_rect()
        self.rect.top = top
        self.rect.left = left

#Basic class for drawable objects
class Obj():
    def __init__(self,image_path,top=0,left=0):
        self.imagen= loadImA(image_path)
        self.imagen_default = self.imagen.copy()
        self.rect=self.imagen.get_rect()
        self.rect.top = top
        self.rect.left = left

class MouseRect(pygame.Rect):
    def __init__(self):
        pygame.Rect.__init__(self,0,0,1,1)
    def update(self):
        self.left,self.top=pygame.mouse.get_pos()
        
class MenuLevels():
    def __init__(self,matriztriple, displayWidth, displayHeight):
        self.img_botones = [ (loadImA(e[0]),loadImA(e[1])) for e in matriztriple ]
        self.img_rect = [ pygame.Rect(*e[2]) for e in matriztriple ]
        self.img_fondo = [ loadIm(e[3]) for e in matriztriple ]
        
    def update(self, surf):
        MouseRect=pygame.Rect(pygame.mouse.get_pos(),(1,1))
        collide = False
        for i in range(len(self.img_rect)):
            ri = self.img_rect[i]
            if MouseRect.colliderect(ri):
                surf.blit(self.img_fondo[i],(0,0))
                surf.blit(self.img_botones[i][1],(ri.left,ri.top-10))
                collide = True
            elif not collide:
                surf.blit(self.img_botones[i][0],ri)
        
class Botones():
    def __init__(self,imageorig_path,imageedit_path,x,y):
        self.imgoriginal=loadImA(imageorig_path)
        self.imgeditada=loadImA(imageedit_path)
        self.imgreal=self.imgoriginal
        self.imgpos=self.imgoriginal.get_rect()
        self.imgpos.left,self.imgpos.top=(x,y)

    def update(self,surface,cursor):
        if cursor.colliderect(self.imgpos):
            self.imgreal=self.imgeditada
        else: 
            self.imgreal=self.imgoriginal
        surface.blit(self.imgreal,self.imgpos)

class TextObj:
    def __init__(self, font, text, color):
        self.textSurface = font.render(text, True, color)
        self.textRect = self.textSurface.get_rect()
    
    def update_center(self, surf, center):
        self.textRect.center = center
        surf.blit(self.textSurface, self.textRect)
    
    def update_left_top(self, surf, left, top):
        self.textRect.left = left
        self.textRect.top = top
        surf.blit(self.textSurface, self.textRect)

class GameBar(Sup):
    def __init__(self, fontObj,width,height,top=0,left=0):
        Sup.__init__(self,width,height,top,left)
        self.background_surf = self.surf.copy()
        self.background_surf.fill(YELLOW)
        self.fontObj = fontObj

        TextObj(self.fontObj, "Score", BLACK).update_center(self.background_surf, (self.rect.width/2,50))
        
        
        TextObj(self.fontObj, "Lifes", BLACK).update_center(self.background_surf, (self.rect.width/2,150))
        

        TextObj(self.fontObj, "Time", BLACK).update_center(self.background_surf, (self.rect.width/2,320))
        
    
    def update(self,pacObj):
        self.surf.blit(self.background_surf, (0,0))
        tmpv = TextObj(self.fontObj, str(pacObj.coins_eaten*50), BLACK)
        tmpv.update_center(self.surf, (self.rect.width/2,100))
        
        life_blit(pacObj, self.surf)
        
        tmpv = TextObj(self.fontObj, str(round(pygame.time.get_ticks()/1000.0,1)), BLACK)
        tmpv.update_center(self.surf, (self.rect.width/2,350))

#===============================================================================
# Game utilities
#===============================================================================

#Configuration class
class Configuration():
    def __init__(self, **entries):
        self.__dict__.update(entries)

def attributes_list_to_configuration(att_names, attributes):
    conf_dict = dict()
    for name in att_names:
        conf_dict[name] = []
    for atts in attributes:
        for i in range(len(atts)):
            conf_dict[att_names[i]].append(atts[i])
    return Configuration(**conf_dict)
"""
#Example of use of attributes_list_to_configuration function
y = attributes_list_to_configuration(["my_pos"],[[((0,1),(1,0))]])
print(y.my_pos)
#>>((0, 1), (1, 0))
"""

def life_blit(pacObj,surf):
        i = 1
        j = 1
        rect_life = pacObj.life_surf.get_rect()
        for e in range(pacObj.lifes):
            rect_life.top = (i-1)*50+200
            rect_life.left = (j-1)*40+15
            i+= 1 if j%3 == 0 else 0
            j = (j%3)+1
            surf.blit(pacObj.life_surf,rect_life)

#Basic class for drawable objects in game
class GameObj():
    """useful as a base class for game objects
    """
    def __init__(self, image_path="", top=0, left=0, width = 1, height = 1):
        self.image = get_list_image(image_path,width=width,height=height)
                
        #index of the image in self.image to blit
        self.actual = 0
        #colision rect
        self.colrect = self.image[self.actual].get_rect()
        self.colrect.top = top
        self.colrect.left = left
        #animation rect
        self.anirect = self.colrect.copy()
        #controls the blit (visibility) of the object
        self.visible = True
    
    def update(self,rel_sup):
        """refresh properties of the object

        rel_sup is a Sup object that change the relative pos of GameObj's for collide
        """
        self.colrect.left = self.anirect.left + rel_sup.rect.left
        self.colrect.top = self.anirect.top + rel_sup.rect.top
    
    def blit(self, surface):
        """blit object into surface
        """
        if self.visible:
            surface.blit(self.image[self.actual], self.anirect)

class GameObjCollection():
    """useful as a base class for collection of game objects
    """
    def __init__(self, image_path, pos):
        """pos is a iterable of (top, left) positions
        """
        self.objects = []
        self.image = get_list_image(image_path)
        for p in pos:
            obji = GameObj(self.image, p[0], p[1])
            obji.image = self.image
            self.objects.append(obji)
    
    def update(self,rel_sup):
        for e in self.objects:
            e.update(rel_sup)
    
    def blit(self, surface):
        """blit object into surface
        """
        for e in self.objects:
            e.blit(surface)
    
    def add_movement(self, movement_function, *args):
        """movement_function is a function in ObjMovements functions or similar

        if movement_function is an iterable then is assumed that is a collection
        of functions with at most the length of self.objects
        """
        try:
            for i in range(len(movement_function)):
                movement_function[i](self.objects[i],*args[i])
        except TypeError:
            for obji in self.objects:
                movement_function(obji, *args)
    
    def add_animation(self, animation_function, *args):
        """animation_function is a function in ObjAnimations functions or similar

        if animation_function is an iterable then is assumed that is a collection
        of functions with at most the length of self.objects
        """
        try:
            for i in range(len(animation_function)):
                animation_function[i](self.objects[i],*args[i])
        except TypeError:
            for obji in self.objects:
                animation_function(obji, *args)

    def get_colrects(self):
        return [e.colrect for e in self.objects]   

class LifesUp(GameObjCollection):
    def __init__(self, image_path, pos):
        """pos is a iterable of (top, left) positions
        """
        GameObjCollection.__init__(self, image_path, pos)
 
class Coins(GameObjCollection):
    def __init__(self,image_path,text):
        coin_pos = []
        for i in range(len(text)):
            for j in range(len(text[i])):
                if text[i][j] == " ":
                    coin_pos.append((i*50+15, j*50+19))
        image = pygame.transform.scale(loadImA(image_path), (13,21))
        GameObjCollection.__init__(self, image, coin_pos)
        
        
        self.rects=[e.colrect for e in self.objects]
        self.amount=len(self.rects)

class Enemies(GameObjCollection):
     def __init__(self, image_path, pos, config=None):
        """pos is a iterable of (top, left) positions.
        config is a Configuration object
        """
        GameObjCollection.__init__(self, image_path, pos)
        if config:
            #check if is defined a movement function
            if hasattr(config, 'mov_f'):
                self.add_movement(config.mov_f, *config.mov_f_args)
            
            if hasattr(config, 'ani_f'):
                self.add_animation(config.ani_f, *config.ani_f_args)

class ObjMovements():
    """The methods of this class should be used with GameObj or derived classes
    """
    @staticmethod
    def vectorial_movement(obj,points,velocity):
        """this function asumes that with the given velocity, the object can reach
        the given points, if not, it will loop over the first no reachable point.

        The object will move with the given velocity in both coordantes.
        points is a iterable of (top, left) positions.
        This method can not be combine with others method that perfom a copy in prev_update
        """
        obj.points = points
        obj.velocity = velocity
        obj.next_point = 0
        obj.prev_update = obj.update
        if not hasattr(obj, 'leftimage'): #to consider
            obj.leftimage = obj.image
        if not hasattr(obj, 'rightimage'): #to consider
            obj.rightimage = [pygame.transform.flip(e,True,False) for e in obj.image]

        def update(self, *args):
            if self.points[self.next_point] == (self.anirect.top, self.anirect.left):
                self.next_point = (self.next_point+1)%len(self.points)
            vx = self.velocity*sign(self.points[self.next_point][1] - self.anirect.left)
            vy = self.velocity*sign(self.points[self.next_point][0] - self.anirect.top)
            if vx>0: #to consider
                self.image = self.rightimage
            else:
                self.image = self.leftimage
            self.anirect.move_ip(vx,vy)
            self.prev_update(*args)
        obj.update = MethodType(update, obj)
    
    @staticmethod
    def vertical_movement(obj,points,velocity):
        """points is a tuple of the form (start, stop) where start and stop are positions
        """
        points = ((points[0], obj.anirect.left), (points[1], obj.anirect.left))
        ObjMovements.vectorial_movement(obj, points, velocity)
    
    @staticmethod
    def horizontal_movement(obj,points,velocity):
        """points is a tuple of the form (start, stop) where start and stop are positions
        """
        points = ((obj.anirect.top, points[0]), (obj.anirect.top, points[1]))
        ObjMovements.vectorial_movement(obj, points, velocity)

class ObjAnimations():
    """The methods of this class should be used with GameObj or derived classes
    """
    @staticmethod
    def linear_image_change(obj, nframestochange):
        obj.prev_ani_update = obj.update
        obj.nframestochange = nframestochange
        obj.nframes = 0
        
        def update(self, *args):
            self.nframes += 1
            if self.nframes == self.nframestochange:
                self.actual = (self.actual+1)%len(self.image)
                self.nframes = 0
            self.prev_ani_update(*args)
        obj.update = MethodType(update, obj)

class Muros():
    def __init__(self,muros_att,texto):
        """build rectangle collide and image position lists for the walls

        muros_att is a dict of lists of the form:
            character: [image path, is wall?]
        texto is a iterable of strings, all with the same length and
        each character of a string must be in muros_att[i] for
        some key i.
        """
        self.muro = []

        for e in muros_att:
            muros_att[e][0] = loadIm(muros_att[e][0])
        
        acumy = 0
        #collide rectangles within a line
        r_wall=[]
        for linea in texto:
            l_wall=[]
            l_width=0
            acumx = 0
            for c in linea:
                imagen = muros_att[c][0]
                imagenr = imagen.get_rect()
                imagenr.left = acumx
                imagenr.top = acumy
                acumx += imagenr.width
                self.muro.append([imagen,imagenr])
                if muros_att[c][1]:
                    l_width+=imagenr.width
                else:
                    if l_width:
                        l_wall.append(pygame.Rect(acumx-l_width-imagenr.width,acumy,l_width,imagenr.height))
                        l_width=0
            if l_width:
                l_wall.append(pygame.Rect(acumx-l_width,acumy,l_width,imagenr.height))
            r_wall+=l_wall
            acumy += imagenr.height
        
        # sort array for optimal search
        r_wall.sort(key = lambda e: e.top)
        r_wall.sort(key = lambda e: e.left)

        #collide rectangles for the map
        self.final_wall=[]
        l_height=imagenr.height
        i = 0
        j = 1
        while j < len(r_wall): #this algorithm is O( N+2*N*log(N) ), can it be better?
            if r_wall[j-1].left != r_wall[j].left or \
                r_wall[j].top-r_wall[j-1].top != l_height or \
                r_wall[j-1].width != r_wall[j].width:
                self.final_wall.append(
                    pygame.Rect(r_wall[i].left, r_wall[i].top, 
                                r_wall[i].width, (j-i)*l_height)
                )
                i = j
            j += 1
        self.final_wall.append(
            pygame.Rect(r_wall[i].left, r_wall[i].top, 
                        r_wall[i].width, (j-i)*l_height)
        )
        self.colrects = [e.copy() for e in self.final_wall]
    
    def update(self, rel_sup):
        for i in range(len(self.colrects)):
            self.colrects[i].left = self.final_wall[i].left + rel_sup.rect.left
            self.colrects[i].top = self.final_wall[i].top + rel_sup.rect.top


    def blit(self,surf):
        for e in self.muro:
            surf.blit(e[0],e[1])

class Pacman(GameObj):
    def __init__(self, image_paths):
        GameObj.__init__(self, image_paths)
        ObjAnimations.linear_image_change(self, 20)

        # Useful for calculating map movement
        self.limitleft=0
        self.limittop=0
        self.prev_display_offset = (0,0)

        # Image for movements
        self.rightimage = self.image
        self.leftimage = [pygame.transform.flip(e,True,False) for e in self.image]
        self.upimage = [pygame.transform.rotate(e,90) for e in self.image]
        self.downimage = [pygame.transform.rotate(e,270) for e in self.image]

        # scale and position of collision rect
        self.colrect.width *= 0.8
        self.colrect.height *= 0.8
        self.colrect.center = (self.anirect.width/2,self.anirect.height/2)

        # Define movements 
        self.MovDirClass = namedtuple('MovDirClass', 'r ru u lu l ld d rd')
        self.movDir = self.MovDirClass(0, 1 ,2 ,3 ,4 ,5, 6, 7)
        self.direccion= self.movDir.r

        # attributes
        self.lifes = 3
        self.life_surf = pygame.transform.scale(self.image[0], (40,40)) # image for life display
        self.coins_eaten = 0 # total
        self.level_coins_eaten = 0 # for each level
        self.velocity = 3
    def next_level(self, initx=50, inity=50):
        self.limitleft = 0
        self.limittop = 0
        self.prev_display_offset = (0,0)
        self.position(initx, inity)
        self.direccion = self.movDir.r
        self.level_coins_eaten = 0  

    def reset(self,initx=50,inity=50):
        self.next_level(initx, inity)
        self.coins_eaten = 0
        self.lifes = 3

    def position(self,x,y):
        self.anirect.top = y
        self.anirect.left = x
        self.colrect.center = (self.anirect.width/2+x,self.anirect.height/2+y)
    
    def position_rel(self,x,y):
        self.position(self.anirect.left + x, self.anirect.top + y)

    def update(self, display_level, wallObj, coinsObj, lifesObj, enemiesObjlist):
        # Necessary for correct display
        offsetx = self.prev_display_offset[0] - display_level.rect.left
        offsety = self.prev_display_offset[1] - display_level.rect.top
        self.position_rel(-offsetx, -offsety)
        self.prev_display_offset = (display_level.rect.left,display_level.rect.top)
        self.limitleft = -display_level.rect.left
        self.limittop = -display_level.rect.top

        prevx, prevy=self.anirect.left,self.anirect.top
        
        # move based on the last pressed keys
        if self.direccion == self.movDir.r:
            self.position_rel(self.velocity, 0)
            self.image = self.rightimage
        elif self.direccion == self.movDir.l:
            self.position_rel(-self.velocity, 0)
            self.image = self.leftimage
        elif self.direccion == self.movDir.u:
            self.position_rel(0, -self.velocity)
            self.image = self.upimage
        elif self.direccion == self.movDir.d:
            self.position_rel(0, self.velocity)
            self.image = self.downimage

        # check if it collide with a wall
        for e in wallObj.colrects:
            if self.colrect.colliderect(e):
                self.position(prevx, prevy)
        
        # check if it collide with a coin
        for e in coinsObj.objects:
            if e.visible and self.colrect.colliderect(e.colrect):
                self.coins_eaten += 1
                self.level_coins_eaten += 1
                e.visible = False
        
        # check if it collide with a life bonus
        if lifesObj:
            for e in lifesObj.objects:
                if e.visible and self.colrect.colliderect(e.colrect):
                    self.lifes += 1
                    e.visible = False
        
        # check if it collide with a enemie
        for enemiesObj in enemiesObjlist:
            for e in enemiesObj.objects:
                if self.colrect.colliderect(e.colrect):
                    self.lifes -= 1
                    display_level.rect.left = 0
                    display_level.rect.top = 0
                    self.limitleft = 0
                    self.limittop = 0
                    self.prev_display_offset = (0,0)
                    self.position(50,50)
 