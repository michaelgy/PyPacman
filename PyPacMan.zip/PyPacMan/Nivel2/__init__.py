from Utilidades import *

nivel = 2

# aliasing large name functions
vec_mov = ObjMovements.vectorial_movement
ver_mov = ObjMovements.vertical_movement
hor_mov = ObjMovements.horizontal_movement

class CannonBalls(Enemies):
    def __init__(self, image_paths, config):
        Enemies.__init__(self, image_paths, config.pos, config)
        #self.add_animation(ObjAnimations.linear_image_change,(30))

class Soldiers(Enemies):
    def __init__(self, image_paths, config):
        Enemies.__init__(self, image_paths, config.pos, config)
        self.add_animation(ObjAnimations.linear_image_change,(30))
        for obji in self.objects:
            tmp = obji.leftimage
            obji.leftimage = obji.rightimage
            obji.rightimage = tmp

#Crear los enemigos del nivel
cannonball_impaths = ["Nivel2/CannonBall.png"]
cannonball_attnames = ["pos","mov_f","mov_f_args"]
cannonball_att = [
    ((457,157), hor_mov, ((157,607),2)),
    ((457,607), hor_mov, ((157,607),2)),
    ((507,157), hor_mov, ((157,607),2)),
    ((557,607), hor_mov, ((157,607),2)),
    ((307,157), hor_mov, ((157,607),2)),
    ((257,157), hor_mov, ((157,607),2)),
    ((207,157), hor_mov, ((157,607),2)),
    ((157,157), hor_mov, ((157,607),2)),
    ((257,607), hor_mov, ((157,607),2)),
    ((207,607), hor_mov, ((157,607),2)),
    ((157,607), hor_mov, ((157,607),2)),
    ((57,407), ver_mov, ((57,707),2)),
    ((57,357), ver_mov, ((57,707),2)),
    ((807,257), ver_mov, ((807,1207),2)),
    ((807,457), ver_mov, ((807,1207),2)),
    ((307,607), hor_mov, ((157,607),2)),
    ((807,257), hor_mov, ((257,507),2)),
    ((907,207), hor_mov, ((207,607),2)),
    ((857,557), hor_mov, ((207,557),2)),
    ((957,557), hor_mov, ((57,557),2)),
    ((1057,157), hor_mov, ((157,457),2)),
    ((1107,257), hor_mov, ((157,257),2)),
    ((1157,357), hor_mov, ((357,457),2)),
    ((57,157), ver_mov, ((57,307),2)),
    ((57,607), ver_mov, ((57,307),2)),
    ((307,207), ver_mov, ((57,307),2)),
    ((307,557), ver_mov, ((57,307),2))
]
cannonballsObj = CannonBalls(cannonball_impaths, attributes_list_to_configuration(cannonball_attnames, cannonball_att))

soldier_impaths = ["Nivel2/Soldier1.png","Nivel2/Soldier2.png"]
soldier_attnames = ["pos", "mov_f", "mov_f_args"]
soldier_att = [
    ((207,707), hor_mov, ((707,1057),2)),
    ((657,707), hor_mov, ((707,1057),2)),
]
soldierObj = Soldiers(soldier_impaths, attributes_list_to_configuration(soldier_attnames, soldier_att))

#Actualizar con la lista de enemigos
ENEMIGOS = cannonballsObj.get_colrects()+soldierObj.get_colrects()
enemigosObj = [cannonballsObj,soldierObj]

# Muros Nivel
l_texto = ["##2#####2#####55##2######",
            "#1#44444444444####55##2##",
            "#1#4444444444##5#########",
            "2154444444444###2####2###",
            "#1#4444444444#         ##",
            "51#4444444444# ## # ## #2",
            "#124444444444# #  #  # ##",
            "#1#4444444444#    #    #5",
            "#1#44444444445 #     # 5#",
            "#154444444444# # ### # ##",
            "21#4444444444# #     # #2",
            "#124444444444#    #    ##",
            "#124444444444#2 # # 5 #5#",
            "51#4444444444#          #",
            "#1#4444444444## 2 # # ##5",
            "#1#5#7#1#7#5##          #",
            "#1##3111111#2## # 5 # #2#",
            "#1#2111111116#    5     #",
            "#1#31111111112 #     # ##",
            "5111111111116# # 2#2 # ##",
            "#52111#1#1#5## #     # #5",
            "##311111112#11   2##   2#",
            "###1116111211# #  #  # 2#",
            "#5#1113111#1## 5# # 5# ##",
            "#5#111#11111##         #2",
            "##5###2#55###5####2###2##",
            "###2####22####55########5"
]

DISPLAY_BACKGROUND = Sup(len(l_texto[0])*50,len(l_texto)*50)

muros_att = {
    " ":["Nivel2/Calle1.png", False],   "#":["Nivel2/House2.png",True],
    "1":["Nivel2/Calle2.png",False],    "2":["Nivel2/House1.png",True],
    "3":["Nivel2/Cannon1.png",True],    "4":["Nivel2/Calle3.png",False],
    "5":["Nivel2/House3.png",True],     "6":["Nivel2/Cannon2.png",True],
    "7":["Nivel2/Cannon3.png",True]
}

muros = Muros(muros_att ,l_texto)

# Cargar el fondo a la superficie fondo
DISPLAY_BACKGROUND.surf.fill(WHITE)
muros.blit(DISPLAY_BACKGROUND.surf)

# Monedas
coins=Coins("coins.png",l_texto)

# Bonus
BonusPos = ((100, 400), (100, 600))
Bonus = LifesUp("Lifeup.png", BonusPos)

# Banderola (meta)
banderola = GameObj("Target.png",50, 650)

# collections of objects for general actions
update_objects = [muros, coins, Bonus, banderola,  *enemigosObj]
blit_objects = [coins, Bonus, banderola,  *enemigosObj]

DISPLAY_LEVEL = Sup(len(l_texto[0]*50),len(l_texto*50))

def reset_level():
    global coins, Bonus, DISPLAY_LEVEL
    DISPLAY_LEVEL.rect.left = 0
    DISPLAY_LEVEL.rect.top = 0
    for e in coins.objects:
        e.visible = True
    for e in Bonus.objects:
        e.visible = True