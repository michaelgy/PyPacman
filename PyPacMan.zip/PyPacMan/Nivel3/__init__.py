from Utilidades import *

nivel = 3

# aliasing large name functions
vec_mov = ObjMovements.vectorial_movement
ver_mov = ObjMovements.vertical_movement
hor_mov = ObjMovements.horizontal_movement

class SnowMan(Enemies):
    def __init__(self, image_paths, config):
        Enemies.__init__(self, image_paths, config.pos, config)
        self.add_animation(ObjAnimations.linear_image_change,(30))

class IceGolem(Enemies):
    def __init__(self, image_paths, config):
        Enemies.__init__(self, image_paths, config.pos, config)
        self.add_animation(ObjAnimations.linear_image_change,(30))
        for obji in self.objects:
            tmp = obji.leftimage
            obji.leftimage = obji.rightimage
            obji.rightimage = tmp

#Crear los enemigos del nivel
snowman_impaths = ["Nivel3/SnowMan1.png","Nivel3/SnowMan2.png",
                    "Nivel3/SnowMan3.png"]
snowman_attnames = ["pos"]
snowman_att = [
    [(457,93)]
]
snowmansObj = SnowMan(snowman_impaths, attributes_list_to_configuration(snowman_attnames, snowman_att))

icegolem_impaths = ["Nivel3/IceGolem1.png","Nivel3/IceGolem2.png"]
icegolem_attnames = ["pos", "mov_f", "mov_f_args"]
icegolem_att = [
    ((207,707), hor_mov, ((707,1057),2)),
    ((657,707), hor_mov, ((707,1057),2)),
]
icegolemsObj = IceGolem(icegolem_impaths, attributes_list_to_configuration(icegolem_attnames, icegolem_att))

#Actualizar con la lista de enemigos
ENEMIGOS = snowmansObj.get_colrects()+icegolemsObj.get_colrects()
enemigosObj = [snowmansObj,icegolemsObj]

# Muros Nivel
l_texto = load_level_design("Nivel3")

muros_att = {
    " ":["Nivel3/Snow1.png", False],   "#":["Nivel3/SnowTree1.png",True],
    "1":["Nivel3/Snow2.png", False],    "2":["Nivel3/SnowTree1.png",True],
    "3":["Nivel3/Snow3.png", False],    "4":["Nivel3/SnowRock1_0.png",True],
    "5":["Nivel3/SnowRock1_1.png",True],
}

muros = Muros(muros_att ,l_texto)

# Cargar el fondo a la superficie fondo
DISPLAY_BACKGROUND = Sup(len(l_texto[0])*50,len(l_texto)*50)
DISPLAY_BACKGROUND.surf.fill(WHITE)
muros.blit(DISPLAY_BACKGROUND.surf)

# Monedas
coins=Coins("coins.png",l_texto)

# Bonus
BonusPos = ((100, 400), (100, 600))
Bonus = LifesUp("Lifeup.png", BonusPos)

# Banderola (meta)
banderola = GameObj("Target.png",50, 650)

# collections of objects for general actions
update_objects = [muros, coins, Bonus, banderola,  *enemigosObj]
blit_objects = [coins, Bonus, banderola,  *enemigosObj]

DISPLAY_LEVEL = Sup(len(l_texto[0]*50),len(l_texto*50))

def reset_level():
    global coins, Bonus, DISPLAY_LEVEL
    DISPLAY_LEVEL.rect.left = 0
    DISPLAY_LEVEL.rect.top = 0
    for e in coins.objects:
        e.visible = True
    for e in Bonus.objects:
        e.visible = True