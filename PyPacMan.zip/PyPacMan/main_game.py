#===============================================================================
# En este espacio solo se van a realizar importaciones de librerias o modulos
#===============================================================================
import sys, pygame, os, random
from pygame.locals import *
from Utilidades import *


#===============================================================================
# Constantes
#===============================================================================
# Esta declaracion siempre va aqui ---------------------------------------------
pygame.init()
debug = False
debugf = True
if debugf:
    dbfile = open("debug_file.txt","w+")

#pygame.mixer.music.load("Thexxintro.ogg")
#pygame.mixer.music.play(-1)

# Pantalla ---------------------------------------------------------------------
DISPLAY_WIDTH = 1280
DISPLAY_HEIGHT = 720
DISPLAY_FLAGS = 0 #FULLSCREEN
DISPLAY_DEPTH = 32 #Opcional

# Cuadros por segundo ----------------------------------------------------------
FPS = 60
fpsClock = pygame.time.Clock()

# Inicializacion de la pantalla ------------------------------------------------
x = pygame.display.mode_ok((DISPLAY_WIDTH,DISPLAY_HEIGHT),DISPLAY_FLAGS,DISPLAY_DEPTH)
DISPLAY_SURF = pygame.display.set_mode((DISPLAY_WIDTH,DISPLAY_HEIGHT),DISPLAY_FLAGS,DISPLAY_DEPTH)

#Configuracion de la pantalla
import Principal

# Inicializacion de las superficies del modo juego
DISPLAY_GAME = Sup(800,600, 60, 165)
DISPLAY_BAR = GameBar(Principal.fontObj, 150,720, 0, 1130)


# Titulo del juego --------------------------------------------------------
pygame.display.set_caption("Aleph")
# Icono ------------------------------------------------------------------------
pygame.display.set_icon(loadIm('WhiteBoss.png'))

# Pacman -----------------------------------------------------------------------
pac=Pacman(["AvatarP1.png","AvatarP2.png"])
pac.position(50,50)


# animacion --------------------------------------------------------------------
g_modulo=0
alpha=255
i=1
introm=0
#Mouse
MouseR=MouseRect()

# Estados --------------------------------------------------------------------
# Estados principales
class GStates:
    #Pantalla de inicio
    intro_screen = 0
    #Menu principal
    menu = 1
    #Select Menu
    level_select = 2
    #Juego
    game = 3

# Estados menu
class GStates_menu:
    #Menu en principal
    principal = 0
    #Menu en play
    mplay = 1
    #Menu en info
    minfo = 2
    #Menu en score
    mscore = 3
    #Menu en options
    moptions = 4
    #Menu en creditos
    mcreditos = 5

# Estados seleccionar nivel
class GStates_levelselect:
    normal = 0
    clasico = 1
    survival = 2

# Estados juego
class GStates_level:
    intro = 0
    nivel = 1
    perdiste = 2
    
game_state = GStates.intro_screen #por defecto
menu_state = GStates_menu.principal
levelselect_state = GStates_levelselect.normal
level_state = GStates_level.intro #por defecto
#nivel actual
Lvl=0

#===============================================================================
# Bucle principal

# Etiqueta para indicar que es la primera vez que se ingresa a un estado
tag_first_in = True

while True:
    #Atrapar todos los eventos del juego en la escena actual
    events = pygame.event.get()

    if game_state == GStates.intro_screen:
        introm = (introm+1)%125
        xIntro=Principal.xxIntro(introm)
        DISPLAY_SURF.blit(xIntro.surf,xIntro.rect)

        for event in events:
            if event.type == KEYDOWN:
                if event.key == K_RETURN:
                    game_state = GStates.menu

    elif game_state == GStates.menu:
        xMenu=Principal.xxMenu()
        MouseR.update()

        if menu_state == GStates_menu.principal:
            pass

        elif menu_state == GStates_menu.mplay:
            Principal.BotNormal.update(xMenu.surf,MouseR)
            Principal.BotClassic.update(xMenu.surf,MouseR)
            Principal.BotSurvival.update(xMenu.surf,MouseR)

            for event in events:
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if MouseR.colliderect(Principal.BotNormal.imgpos):
                        menu_state = GStates_menu.principal
                        game_state = GStates.level_select
                        levelselect_state = GStates_levelselect.normal
                    
                    elif MouseR.colliderect(Principal.BotClassic.imgpos):
                        menu_state = GStates_menu.principal
                        game_state = GStates.level_select
                        levelselect_state = GStates_levelselect.clasico
                    
                    elif MouseR.colliderect(Principal.BotSurvival.imgpos):
                        menu_state = GStates_menu.principal
                        game_state = GStates.level_select
                        levelselect_state = GStates_levelselect.survival
                           
        elif menu_state == GStates_menu.minfo:
            pass

        elif menu_state == GStates_menu.mscore:
            
            pass

        elif menu_state == GStates_menu.moptions:
            
            pass

        elif menu_state == GStates_menu.mcreditos:
            TextObj(Principal.fontObj1,"Michael G.", YELLOW).update_center(xMenu.surf,((xMenu.rect.width/2)+200,360))

            TextObj(Principal.fontObj1,"Juan Fer. E.", YELLOW).update_center(xMenu.surf,((xMenu.rect.width/2)+200,460))
                
        Principal.BotPlay.update(xMenu.surf,MouseR)
        Principal.BotInfo.update(xMenu.surf,MouseR)
        Principal.BotScores.update(xMenu.surf,MouseR)
        Principal.BotOptions.update(xMenu.surf,MouseR)
        Principal.BotCredits.update(xMenu.surf,MouseR)

        TextObj(Principal.fontObj1,"Aleph", YELLOWS).update_center(xMenu.surf, (xMenu.rect.width/2,100))

        DISPLAY_SURF.blit(xMenu.surf,xMenu.rect)

        for event in events:
            if event.type==pygame.MOUSEBUTTONDOWN:
                if MouseR.colliderect(Principal.BotPlay.imgpos):
                    if menu_state == GStates_menu.mplay:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.mplay
                
                elif MouseR.colliderect(Principal.BotInfo.imgpos):
                    if menu_state == GStates_menu.minfo:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.minfo
                
                elif MouseR.colliderect(Principal.BotScores.imgpos):
                    if menu_state == GStates_menu.mscore:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.mscore
                
                elif MouseR.colliderect(Principal.BotOptions.imgpos):
                    if menu_state == GStates_menu.moptions:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.moptions

                elif MouseR.colliderect(Principal.BotCredits.imgpos):
                    if menu_state == GStates_menu.mcreditos:
                        menu_state = GStates_menu.principal
                    else:
                        menu_state = GStates_menu.mcreditos
        pass

    elif game_state == GStates.level_select:
        MouseR.update()
        fondo = Principal.xxMenu()
        if levelselect_state == GStates_levelselect.normal:
            Principal.MenuL.update(fondo.surf)
            
            TextObj(Principal.fontObj2, "Normal Mode", YELLOWS).update_center(fondo.surf,(fondo.rect.width*3/4-50,100))
            
            Principal.BotBack.update(fondo.surf,MouseR)
            DISPLAY_SURF.blit(fondo.surf,(0,0))

            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    index = MouseR.collidelist(Principal.MenuL.img_rect)
                    if index>-1:
                        game_state = GStates.game
                        Lvl = index+1
                        level_state = GStates_level.intro

        if levelselect_state == GStates_levelselect.clasico:
            Principal.BotBack.update(fondo.surf,MouseR)
            DISPLAY_SURF.blit(fondo.surf,(0,0))
        
        if levelselect_state == GStates_levelselect.survival:
            Principal.BotBack.update(fondo.surf,MouseR)
            DISPLAY_SURF.blit(fondo.surf,(0,0))

        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if MouseR.colliderect(Principal.BotBack.imgpos):
                    game_state = GStates.menu

    elif game_state == GStates.game:
        if level_state == GStates_level.intro or level_state == GStates_level.perdiste:
            if tag_first_in:
                tag_first_in = False

                #Principal.reset_animHisTexto()
                if level_state == GStates_level.perdiste:
                    Principal.texto_perdiste()
                else:
                    Principal.levelHistTexto(Principal.historia_intro_text[Lvl-1])
                
            MouseR.update()
            xHistoria=Principal.xxHistoria()
            Principal.BotStart.update(xHistoria.surf,MouseR)
            Principal.BotReturn.update(xHistoria.surf,MouseR)
            DISPLAY_SURF.blit(xHistoria.surf,xHistoria.rect)

            Principal.animacionHistTexto(DISPLAY_SURF)

            #indicador para la salida del estado intro/perdiste
            tag_out = False
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if MouseR.colliderect(Principal.BotStart.imgpos):
                        level_state = GStates_level.nivel
                        tag_out = True
                        
                    elif MouseR.colliderect(Principal.BotReturn.imgpos):
                        game_state = GStates.menu
                        tag_out = True
            if tag_out:
                Principal.pergamino_fondo.imagen = Principal.pergamino_fondo.imagen_default.copy()#loadImA("Principal/Historia.png")
                Principal.pergamino_derecha.rect.left=640
                Principal.pergamino_izquierda.rect.left=510
                tag_first_in = True
        
        if level_state == GStates_level.nivel:
            if debugf:
                dbfile.write("x:{:>5d} y:{:>5d}\n".format(pac.anirect.left, pac.anirect.top))
            if tag_first_in:
                tag_first_in = False

                #Niveles config
                if Lvl == 1:
                    if (not 'Nivel' in dir()) or Nivel.nivel != 1:
                        import Nivel1 as Nivel

                elif Lvl == 2:
                    if (not 'Nivel' in dir()) or Nivel.nivel != 2:
                        import Nivel2 as Nivel
                
                elif Lvl == 3:
                    if (not 'Nivel' in dir()) or Nivel.nivel != 3:
                        import Nivel3 as Nivel
                
                else:
                    import Nivel1 as Nivel
                    game_state = GStates.menu
                    tag_first_in = True
            
            
            DISPLAY_GAME.surf.fill(WHITE)

            Nivel.DISPLAY_LEVEL.surf.blit(Nivel.DISPLAY_BACKGROUND.surf,(0,0))
            
            if pac.anirect.left>=DISPLAY_GAME.rect.width/2 and pac.direccion==pac.movDir.r and pac.limitleft<(Nivel.DISPLAY_LEVEL.rect.width-DISPLAY_GAME.rect.width):
                Nivel.DISPLAY_LEVEL.rect.left -= pac.velocity
            elif pac.anirect.left<=DISPLAY_GAME.rect.width/2 and pac.direccion==pac.movDir.l and pac.limitleft>0:
                Nivel.DISPLAY_LEVEL.rect.left += pac.velocity
            
            if pac.anirect.top<=DISPLAY_GAME.rect.height/2 and pac.direccion==pac.movDir.u and pac.limittop>0:
                Nivel.DISPLAY_LEVEL.rect.top += pac.velocity
            elif pac.anirect.top>=DISPLAY_GAME.rect.height/2 and pac.direccion==pac.movDir.d and pac.limittop<(Nivel.DISPLAY_LEVEL.rect.height-DISPLAY_GAME.rect.height):
                Nivel.DISPLAY_LEVEL.rect.top -= pac.velocity
            
            for e in Nivel.update_objects:
                e.update(Nivel.DISPLAY_LEVEL)
            
            pac.update(Nivel.DISPLAY_LEVEL, Nivel.muros, Nivel.coins, Nivel.Bonus, Nivel.enemigosObj)
            

            for e in Nivel.blit_objects:
                e.blit(Nivel.DISPLAY_LEVEL.surf)

            DISPLAY_GAME.surf.blit(Nivel.DISPLAY_LEVEL.surf,Nivel.DISPLAY_LEVEL.rect)
            pac.blit(DISPLAY_GAME.surf)
            
            
            if debug:
                for e in Nivel.muros.colrects:
                    pygame.draw.rect(DISPLAY_GAME.surf, (0,255,255),e, 2)
                for e in Nivel.coins.objects:
                    pygame.draw.rect(DISPLAY_GAME.surf, (0,0,255),e.colrect, 2)
                for obj in Nivel.enemigosObj:
                    for e in obj.objects:
                        pygame.draw.rect(DISPLAY_GAME.surf, (255,0,0),e.colrect, 2)
                pygame.draw.rect(DISPLAY_GAME.surf, (255,0,255),pac.colrect, 2)
            
            DISPLAY_SURF.fill(BLACK)
            DISPLAY_SURF.blit(DISPLAY_GAME.surf,DISPLAY_GAME.rect)
            DISPLAY_BAR.update(pac)
            DISPLAY_SURF.blit(DISPLAY_BAR.surf,DISPLAY_BAR.rect)

            if pac.lifes == 0:
                level_state = GStates_level.perdiste
                pac.reset()
                Nivel.reset_level()
                tag_first_in = True

            elif pac.level_coins_eaten == Nivel.coins.amount and \
                pac.colrect.colliderect(Nivel.banderola.colrect):

                level_state = GStates_level.intro
                pac.next_level()
                Lvl += 1
                if Lvl > len(Principal.MenuL.img_botones):
                    Lvl = 0
                tag_first_in = True



            for event in events:
                if event.type == KEYDOWN:
                    if event.key == K_RIGHT:
                        pac.direccion= pac.movDir.r
                    elif event.key == K_LEFT:
                        pac.direccion= pac.movDir.l
                    elif event.key == K_UP:
                        pac.direccion= pac.movDir.u
                    elif event.key == K_DOWN:
                        pac.direccion= pac.movDir.d
                    
                    if debug:
                        if event.key == K_k:
                            pac.lifes = 0
                        if event.key == K_u:
                            pac.lifes += 1
                        if event.key == K_j:
                            pac.level_coins_eaten = Nivel.coins.amount

            pressed_tuple = pygame.key.get_pressed()
            if pressed_tuple[K_a]:
                Nivel.DISPLAY_LEVEL.rect.left += 4
            if pressed_tuple[K_d]:
                Nivel.DISPLAY_LEVEL.rect.left -= 4
            if pressed_tuple[K_s]:
                Nivel.DISPLAY_LEVEL.rect.top += 4
            if pressed_tuple[K_w]:
                Nivel.DISPLAY_LEVEL.rect.top -= 4

    #Salir del juego
    for event in events:
        if event.type == QUIT:
            print("QUIT event has occurred!")
            pygame.quit()
            sys.exit()
            if debugf:
                dbfile.close()
        elif event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                print("ESCAPE event has occurred!")
                pygame.quit()
                sys.exit()
    
    pygame.display.update()
    fpsClock.tick(FPS)