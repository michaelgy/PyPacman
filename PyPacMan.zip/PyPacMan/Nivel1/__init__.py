from Utilidades import *

nivel = 1

# aliasing large name functions
vec_mov = ObjMovements.vectorial_movement
ver_mov = ObjMovements.vertical_movement
hor_mov = ObjMovements.horizontal_movement

class Osos(Enemies):
    def __init__(self, image_paths, config):
        Enemies.__init__(self, image_paths, config.pos, config)
        self.add_animation(ObjAnimations.linear_image_change,(30))

class Lobos(Enemies):
    def __init__(self, image_paths, config):
        Enemies.__init__(self, image_paths, config.pos, config)
        self.add_animation(ObjAnimations.linear_image_change,(30))
        for obji in self.objects:
            tmp = obji.leftimage
            obji.leftimage = obji.rightimage
            obji.rightimage = tmp

#Crear los enemigos del nivel
osos_impaths = ["Nivel1/Oso1.png","Nivel1/Oso2.png"]
osos_attnames = ["pos","mov_f","mov_f_args"]
osos_att = [
    ((250,700), hor_mov, ((300,700),2)),
    ((400,100), ver_mov, ((150,450),2)),
    ((450,700), ver_mov, ((450,1000),2)),
    ((200,600), hor_mov, ((400,600),2)),
    ((1000,300), ver_mov, ((450,1000),2)),
    ((400,900), ver_mov, ((150,450),2)),
    ((700,100), ver_mov, ((700,1000),2)),
    ((1000,900), ver_mov, ((700,1000),2)),
    ((900,700), hor_mov, ((300,700),2)),
    ((550,300), vec_mov, (((550, 300), (550, 700), (450,700) ,(450,300)),2))
]
ososObj = Osos(osos_impaths, attributes_list_to_configuration(osos_attnames, osos_att))

lobos_impaths = ["Nivel1/Lobo1.png","Nivel1/Lobo2.png"]
lobos_attnames = ["pos", "mov_f", "mov_f_args"]
lobos_att = [
    ((350,300), hor_mov, ((300,700),2)),
    ((600,100), hor_mov, ((100,900),2)),
    ((700,300), hor_mov, ((300,700),2)),
    ((800,400), hor_mov, ((400,600),2))
]
lobosObj = Lobos(lobos_impaths, attributes_list_to_configuration(lobos_attnames, lobos_att))

#Actualizar con la lista de enemigos
ENEMIGOS = ososObj.get_colrects()+lobosObj.get_colrects()
enemigosObj = [ososObj,lobosObj]


# Enemigo prueba
"""
enemiPrueba = GameObj(osos_impaths, 550, 300)
movpoints = ((550, 300), (450,700), (550, 700),(450,300))
ObjMovements.vectorial_movement(enemiPrueba, movpoints, 2)
ObjAnimations.linear_image_change(enemiPrueba,30)
"""

# Muros Nivel
l_texto = ["##22255522#22555222##",
           "# ##2555221225552####",
           "# ###51112121115##3##",
           "#    51222122215   3#",
           "3# # 51211111215 # #3",
           "3#   51111111115   #3",
           "## # 51112121115 # ##",
           "3# # 51111111115 # #3",
           "3#   54555255545   #3",
           "##                 ##",
           "#3# #  # #3# #  # #33",
           "### ##         ## ##3",
           "##                 ##",
           "33# ## ## # ## ## #33",
           "##   #         #   ##",
           "## #   ## # ##   # ##",
           "3# # # #     # # # #3",
           "##   # # #3# # #   #3",
           "3# # #         # # #3",
           "## #   #3##3##   # ##",
           "3#   #         #   #3",
           "###3#3###3#####3#3###",
           "##3###33##3#3#33###3#"
]

DISPLAY_BACKGROUND = Sup(len(l_texto[0])*50,len(l_texto)*50)

muros_att = {
    " ":["Nivel1/Pasto1.png", False],   "#":["Nivel1/Arbol1.png",True],
    "1":["Nivel1/Pasto4.png",False],    "2":["Nivel1/Arbol2.png",True],
    "3":["Nivel1/Arbol3.png",True],     "4":["Nivel1/Madera.png",False],
    "5":["Nivel1/Rio2.png",True]
}

muros = Muros(muros_att ,l_texto)

# Cargar el fondo a la superficie fondo
DISPLAY_BACKGROUND.surf.fill(WHITE)
muros.blit(DISPLAY_BACKGROUND.surf)

# Monedas
coins=Coins("coins.png",l_texto)

# Bonus
BonusPos = ((100, 400), (100, 600))
Bonus = LifesUp("Lifeup.png", BonusPos)

# Banderola (meta)
banderola = GameObj("Target.png",50, 500)

# collections of objects for general actions
update_objects = [muros, coins, Bonus, banderola,  *enemigosObj]
blit_objects = [coins, Bonus, banderola,  *enemigosObj]

DISPLAY_LEVEL = Sup(len(l_texto[0]*50),len(l_texto*50))

def reset_level():
    global coins, Bonus, DISPLAY_LEVEL
    DISPLAY_LEVEL.rect.left = 0
    DISPLAY_LEVEL.rect.top = 0
    for e in coins.objects:
        e.visible = True
    for e in Bonus.objects:
        e.visible = True